/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Define if you have a BLAS library. */
#define HAVE_BLAS 1

/* Define if you have LAPACK library. */
/* #undef HAVE_LAPACK */

/* Define if you have the MPI library. */
#define HAVE_MPI 1

/* Define to 1 if your C compiler doesn't accept -c and -o together. */
/* #undef NO_MINUS_C_MINUS_O */

/* Name of package */
#define PACKAGE "ermod"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "Matubayasi Laboratory"

/* Define to the full name of this package. */
#define PACKAGE_NAME "ermod"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "ermod 0.3.2"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "ermod"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "0.3.2"

/* Version number of package */
#define VERSION "0.3.2"
