Nrep =  10
nmols=  25
nPV = 50 - nmols
PE_atm = 602
PV_atm = 602
i0 = 2 
j0 = i0 + PE_atm

natoms = PV_atm*nPV + PE_atm*nmols

for num in range(1,Nrep+1):
    inputgro = 'MD/min{0:04d}.gro'.format(num)
    print(inputgro)

    with open(inputgro, 'rt') as inpf:
        lines = [line for line in inpf]
    PE_nlines = 2 + PE_atm * nmols
    PV_nlines = 2 + PV_atm * nPV
    box = lines[-1]

    atom_per_chain = PE_atm # PE

    print(nmols)
    print(atom_per_chain)

# PIVOT INDEX OF POLYMER CHAINS

    for molindex in range(1, nmols+1):
        indx = '{0:04d}'.format((num-1)*nmols+molindex)
        outputgro = '../PE_conf/system' +indx+'.gro'
    
        start_atm = 2 + atom_per_chain * (molindex-1)
        end_atm   = start_atm + atom_per_chain
        print('start:',start_atm)
        print('end:',end_atm)
 
        for i0, i in enumerate(range(start_atm, end_atm)):
            i0 = i0 + 2
            #print(lines[i0], lines[i])
            pivot = lines[i0][20:] 

#        print(i-1)
            # i0 <=> i
            lines[i0] = lines[i0][:20] + lines[i][20:]
            lines[i] = lines[i0][:20] + pivot

        PE_lines = lines[2:PE_nlines+1]
        PV_lines = lines[PE_nlines:-1]
        with open(outputgro, 'w+') as outf:
            for i in range(2):
                outf.write(lines[i])
            for i in range(PE_nlines-2):
                outf.write(PE_lines[i])
            for i in range(PV_nlines-2):
                outf.write(PV_lines[i])
            outf.write(box)
