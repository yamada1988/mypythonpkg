#!/bin/bash

cd $PBS_O_WORKDIR
n1=0001
gpuindex=0
python ./script/sample.py stage1 $n1 $gpuindex  >> OUT/log$n1.txt 

cp MD/nvt$n1.gro SYS/system$n1.gro

