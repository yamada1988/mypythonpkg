#!/bin/bash

N=5
gro1=PVDF100.gro
gro2=PE100.gro

na=15
np=15

na1=`expr $na - 1`

Lbox=10

for i in `seq 1 $N`
do

i0=`printf %04d $i`

mpirun -np 1 gmx_mpi insert-molecules  -f $gro1 -ci $gro1 -nmol $na1 -o out$i0.gro -seed $i -box $Lbox -try 2000 -radius 0.010
mpirun -np 1 gmx_mpi insert-molecules  -f out$i0.gro -ci $gro2 -nmol $np -o system$i0.gro -seed $i -box $Lbox -try 6000 -radius 0.010

done
