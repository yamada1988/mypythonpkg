#!/bin/bash

#cd $PBS_O_WORKDIR
mkdir MD OUT
N=5
#n1=0001
gpuindex=0

for i in `seq 1 $N`
do

i0=`printf %04d $i`

python ./script/min.py stage0 $i0 $gpuindex  >> OUT/log$i0.txt 

cp MD/min$i0.gro SYS/system$i0.gro

done
